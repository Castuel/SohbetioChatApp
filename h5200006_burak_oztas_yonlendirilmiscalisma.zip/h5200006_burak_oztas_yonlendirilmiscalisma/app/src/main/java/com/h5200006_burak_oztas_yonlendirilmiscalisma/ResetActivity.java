package com.h5200006_burak_oztas_yonlendirilmiscalisma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ResetActivity extends AppCompatActivity {

    EditText resetPassword;
    Button btnSendResetMail;

    private String email="";

    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset);

        firebaseAuth = FirebaseAuth.getInstance();

        resetPassword = findViewById(R.id.edtResetPassword);
        btnSendResetMail = findViewById(R.id.btnSendResetMail);

        btnSendResetMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateEmail();
            }
        });
    }

    private void validateEmail() {
        // get Data
        email = resetPassword.getText().toString().trim();

        //validate Data

         if(TextUtils.isEmpty(email)){
            // email must be filled
            resetPassword.setError("Email is required");
            return;
        }
         else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
             // email format is invalid , don't proceed further
             resetPassword.setError("Invalid email format");
             return;
         }
        else{
            sendResetLink();
        }

    }

    private void sendResetLink() {

        firebaseAuth.sendPasswordResetEmail(email).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(ResetActivity.this, "Reset Email Sent", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                Toast.makeText(ResetActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }
}
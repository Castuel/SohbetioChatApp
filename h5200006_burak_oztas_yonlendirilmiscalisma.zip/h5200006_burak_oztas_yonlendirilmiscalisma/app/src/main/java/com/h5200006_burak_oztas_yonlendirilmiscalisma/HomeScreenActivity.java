package com.h5200006_burak_oztas_yonlendirilmiscalisma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.h5200006_burak_oztas_yonlendirilmiscalisma.databinding.ActivityHomeScreenBinding;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.menu.ChatsFragment;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.menu.FriendsFragment;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.menu.GroupsFragment;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.menu.RequestsFragment;

import java.util.ArrayList;
import java.util.List;

public class HomeScreenActivity extends AppCompatActivity {


    private ActivityHomeScreenBinding binding;

    private FirebaseAuth firebaseAuth;
    private DatabaseReference rootRef;
    private FirebaseUser firebaseUser;

    FloatingActionButton fabActionBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home_screen);

        rootRef = FirebaseDatabase.getInstance().getReference();
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        setUpWithViewPager(binding.viewPager);
        binding.tabLayout.setupWithViewPager(binding.viewPager);
        setSupportActionBar(binding.toolbarMenu);

        fabActionBtn = findViewById(R.id.fab_action);

        // fabAction butonuna tıklama özelliği verdim.
        fabActionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // fabAction butonuna tıklandığında AllUsersActivity classına yönlendiren intenti tanımladım.
                Intent usersIntent = new Intent(HomeScreenActivity.this, AllUsersActivity.class);
                startActivity(usersIntent);
            }
        });

        binding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                changeFabIcon(position);

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();

        if (firebaseUser == null) {
            // user not logged in , start LoginActivity
            sendUserToLoginActivity();
        } else {
            // verify user existance

            verifyUserExistance();

        }

    }

    @Override
    public void onBackPressed() {

    }





    // Kullanıcının giriş yapıp yapmadığını kontrol eden fonksiyon.


    private void verifyUserExistance() {

        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        rootRef.child("Users").child(currentUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if((snapshot.child("username").exists()))
                {
                    Toast.makeText(HomeScreenActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    sendUserToProfileActivity();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    private void setUpWithViewPager(ViewPager viewPager) {

        HomeScreenActivity.SectionsPagerAdapter adapter = new SectionsPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new ChatsFragment(), "Chats");
        adapter.addFragment(new GroupsFragment(), "Groups");
        adapter.addFragment(new FriendsFragment(), "Friends");
        adapter.addFragment(new RequestsFragment(), "Requests");




        //
        viewPager.setAdapter(adapter);

    }

    private static class SectionsPagerAdapter extends FragmentPagerAdapter {

        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public SectionsPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {

            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);

        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    private void changeFabIcon(final int index) {
        binding.fabAction.hide();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                switch (index) {
                    case 0:
                        binding.fabAction.setImageDrawable(getDrawable(R.drawable.ic_baseline_chat_24));
                        break;
                    case 1:
                        binding.fabAction.setImageDrawable(getDrawable(R.drawable.ic_baseline_group_24));
                        break;
                    case 2:
                        binding.fabAction.setImageDrawable(getDrawable(R.drawable.ic_baseline_block_24));
                        break;
                }
                binding.fabAction.show();

            }
        }, 400);

    }

    private void sendUserToLoginActivity() {

        Intent loginScreen = new Intent(HomeScreenActivity.this, LoginActivity.class);
        loginScreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(loginScreen);
        finish();

    }

    private void sendUserToProfileActivity() {
        Intent profileScreen = new Intent(HomeScreenActivity.this, ProfileActivity.class);
        profileScreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(profileScreen);
        finish();
    }


    private void sendUserToSettingsActivity() {
        Intent settingsScreen = new Intent(HomeScreenActivity.this, SettingsActivity.class);
        startActivity(settingsScreen);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_option, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.menu_profile) {
            sendUserToProfileActivity();
        }
        if (item.getItemId() == R.id.menu_settings) {
            // Ayarlar butonuna tıklandığında kullanıcıyı ProfileActivity sayfasına yönlendiren kod.
            sendUserToSettingsActivity();
        }
        if (item.getItemId() == R.id.menu_logout) {
            // Logout butonuna tıklandığında kullanıcıya uygulamadan çıkış yapmak isteyip istemediğini soran dialog.

            Dialog dialog = new Dialog(HomeScreenActivity.this, R.style.Dialoge);
            dialog.setContentView(R.layout.dialog_layout);

            TextView btnYes, btnNo;

            btnYes = dialog.findViewById(R.id.btnPositiveLogout);
            btnNo = dialog.findViewById(R.id.btnNegativeLogout);

            btnYes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Yes butonuna tıklandığın kullanıcının oturumunu kapatan ve kullanıcıyı LoginActivity'ye yönlendiren fonksiyonları tanımladım.
                    firebaseAuth.signOut();
                    sendUserToLoginActivity();

                }
            });


            btnNo.setOnClickListener(new View.OnClickListener() {
                @Override
                // No butonuna tıklandığına dialog'u kapatan kod bloğu.
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
            dialog.show();

        }
        if (item.getItemId() == R.id.menu_search) {
            Toast.makeText(this, "Action Search", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId() == R.id.menu_createGroup){
            
            requestNewGroup();
        }
        return true;
    }

    private void requestNewGroup()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeScreenActivity.this, R.style.AlertDialog);
        builder.setTitle("Enter Group Name :");

        final EditText groupNameField = new EditText(HomeScreenActivity.this);
        groupNameField.setHint("e.g Sohbetio Friends");
        builder.setView(groupNameField);

        builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                String groupName = groupNameField.getText().toString();

                if (TextUtils.isEmpty(groupName))
                {
                    Toast.makeText(HomeScreenActivity.this, "Please write Group Name...", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    createNewGroup(groupName);
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                dialogInterface.cancel();
            }
        });

        builder.show();
    }


    private void createNewGroup(final String groupName)
    {
        rootRef.child("Groups").child(groupName).setValue("")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task)
                    {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(HomeScreenActivity.this, groupName + " group is Created Successfully...", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }



}
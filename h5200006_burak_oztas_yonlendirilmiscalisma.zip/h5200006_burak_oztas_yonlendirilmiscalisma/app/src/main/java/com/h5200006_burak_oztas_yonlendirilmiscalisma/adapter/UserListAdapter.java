package com.h5200006_burak_oztas_yonlendirilmiscalisma.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.h5200006_burak_oztas_yonlendirilmiscalisma.R;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.User;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.UsersViewHolder> {

    Context context;
    ArrayList<User> userList;

    public UserListAdapter(Context context, ArrayList<User> userList) {
        this.context = context;
        this.userList = userList;
    }

    @NonNull
    @Override
    public UsersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout_users_list, parent, false);
        return new UsersViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersViewHolder holder, int position) {

        User user = userList.get(position);
        holder.userName.setText(user.getUsername());
        holder.userStatus.setText(user.getStatus());

    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class UsersViewHolder extends RecyclerView.ViewHolder {

        TextView userName, userStatus;
        CircleImageView profileImage;

        public UsersViewHolder(@NonNull View itemView) {
            super(itemView);

            userName = itemView.findViewById(R.id.txtDisplayUsername);
            userStatus = itemView.findViewById(R.id.txtDisplayUserStatus);
            profileImage = itemView.findViewById(R.id.crcDisplayProfileImage);
        }
    }
}

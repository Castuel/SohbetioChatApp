package com.h5200006_burak_oztas_yonlendirilmiscalisma;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.adapter.UserListAdapter;
import com.squareup.picasso.Picasso;


import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class AllUsersActivity extends AppCompatActivity {

    private DatabaseReference usersRef;

    RecyclerView allUsersRecyclerView;
    UserListAdapter userListAdapter;
    ArrayList<User> userList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_users);

        usersRef = FirebaseDatabase.getInstance().getReference("Users");

        allUsersRecyclerView = findViewById(R.id.rycviewNewUsers);

        allUsersRecyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerOptions<User> options =
                new FirebaseRecyclerOptions.Builder<User>()
                        .setQuery(usersRef, User.class)
                        .build();


        FirebaseRecyclerAdapter<User, AllUsersViewHolder> adapter =
                new FirebaseRecyclerAdapter<User, AllUsersViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull AllUsersViewHolder holder, int position, @NonNull User model) {

                        holder.username.setText(model.getUsername());
                        holder.userStatus.setText(model.getStatus());

                        Picasso.get().load(model.getUserImage()).placeholder(R.drawable.user_proile_icon).into(holder.userProfileImage);

                    }

                    @NonNull
                    @Override
                    public AllUsersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_users_list, parent, false);
                        AllUsersViewHolder viewHolder = new AllUsersViewHolder(view);

                        return viewHolder;
                    }
                };

        allUsersRecyclerView.setAdapter(adapter);

        adapter.startListening();
    }

    public static class AllUsersViewHolder extends RecyclerView.ViewHolder {

        TextView username, userStatus;
        CircleImageView userProfileImage;

        public AllUsersViewHolder(@NonNull View itemView) {
            super(itemView);

            username = itemView.findViewById(R.id.txtDisplayUsername);
            userStatus = itemView.findViewById(R.id.txtDisplayUserStatus);
            userProfileImage = itemView.findViewById(R.id.crcDisplayProfileImage);
        }
    }
}
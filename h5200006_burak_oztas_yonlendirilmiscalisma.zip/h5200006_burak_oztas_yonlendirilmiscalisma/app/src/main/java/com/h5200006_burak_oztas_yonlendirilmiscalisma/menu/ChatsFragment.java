package com.h5200006_burak_oztas_yonlendirilmiscalisma.menu;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.h5200006_burak_oztas_yonlendirilmiscalisma.R;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.adapter.ChatListAdapter;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.model.ChatList;

import java.util.ArrayList;
import java.util.List;


public class ChatsFragment extends Fragment {



    public ChatsFragment() {
        // Required empty public constructor
    }


    private List<ChatList> list = new ArrayList<>();
    private RecyclerView recyclerView;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_chats, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewChats);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        getChatList();
        return view;
    }

    private void getChatList() {
        list.clear();
        list.add(new ChatList("15","Ali","Hello, how are you","15/04/2020","https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"));
        list.add(new ChatList("12","Çağatay","Hi, I'm new here","15/04/2020","https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"));
        list.add(new ChatList("10","Burak","Welcome to Sohbetio","15/04/2020","https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"));

        recyclerView.setAdapter(new ChatListAdapter(list,getContext()));
    }
}
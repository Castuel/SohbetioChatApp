package com.h5200006_burak_oztas_yonlendirilmiscalisma.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.R;
import com.h5200006_burak_oztas_yonlendirilmiscalisma.model.ChatList;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.Holder> {
    private List<ChatList> list;
    private Context context;

    public ChatListAdapter(List<ChatList> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_chat_list, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        ChatList chatList = list.get(position);

        holder.chatUserName.setText(chatList.getUserName());
        holder.chatUserDesc.setText(chatList.getUserDescription());
        holder.chatDate.setText(chatList.getDate());

        // for image

        Glide.with(context).load(chatList.getUrlProfile()).into(holder.chatUserProfile);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class Holder extends RecyclerView.ViewHolder {

        private TextView chatUserName, chatUserDesc, chatDate;
        private CircleImageView chatUserProfile;

        public Holder(@NonNull View itemView) {
            super(itemView);

            chatDate = itemView.findViewById(R.id.txtChatDate);
            chatUserName = itemView.findViewById(R.id.txtChatUsername);
            chatUserDesc = itemView.findViewById(R.id.txtChatUserDesc);
            chatUserProfile = itemView.findViewById(R.id.crcUserImage);
        }
    }
}
